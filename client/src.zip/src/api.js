import axios from 'axios';

const API = axios.create({ baseURL: '/api' });

API.interceptors.request.use((config) => {
  const token = localStorage.getItem('lib_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

API.interceptors.response.use(
  res => res,
  err => {
    // Auto logout on 401
    if (err.response?.status === 401 && err.response?.data?.message === 'Invalid token.') {
      localStorage.removeItem('lib_token');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// Auth
export const loginAPI = (data) => API.post('/auth/login', data);
export const registerAPI = (data) => API.post('/auth/register', data);
export const getMeAPI = () => API.get('/auth/me');
export const updateProfileAPI = (data) => API.put('/auth/profile', data);
export const changePasswordAPI = (data) => API.put('/auth/change-password', data);
export const forgotPasswordAPI = (data) => API.post('/auth/forgot-password', data);
export const resetPasswordAPI = (token, data) => API.put(`/auth/reset-password/${token}`, data);

// Addresses
export const getSavedAddressesAPI = () => API.get('/auth/addresses');
export const saveAddressAPI = (data) => API.post('/auth/addresses', data);
export const deleteAddressAPI = (idx) => API.delete(`/auth/addresses/${idx}`);

// Users (Admin)
export const getUsersAPI = (params) => API.get('/users', { params });
export const createUserAPI = (data) => API.post('/users', data);
export const updateUserAPI = (id, data) => API.put(`/users/${id}`, data);
export const deleteUserAPI = (id) => API.delete(`/users/${id}`);
export const toggleUserAPI = (id) => API.put(`/users/${id}/toggle`);
export const resetUserPasswordAPI = (id, data) => API.put(`/users/${id}/reset-password`, data); // requires server route

// Books
export const getBooksAPI = (params) => API.get('/books', { params });
export const getBookAPI = (id) => API.get(`/books/${id}`);
export const createBookAPI = (data) => API.post('/books', data);
export const updateBookAPI = (id, data) => API.put(`/books/${id}`, data);
export const deleteBookAPI = (id) => API.delete(`/books/${id}`);
export const getCategoryCountsAPI = () => API.get('/books/category-counts');

// Members
export const getMembersAPI = (params) => API.get('/members', { params });
export const createMemberAPI = (data) => API.post('/members', data);
export const updateMemberAPI = (id, data) => API.put(`/members/${id}`, data);
export const deleteMemberAPI = (id) => API.delete(`/members/${id}`);

// Issues
export const getIssuesAPI = (params) => API.get('/issues', { params });
export const createIssueAPI = (data) => API.post('/issues', data);
export const returnBookAPI = (id) => API.put(`/issues/${id}/return`);
export const deleteIssueAPI = (id) => API.delete(`/issues/${id}`);

// Dashboard
export const getDashboardAPI = () => API.get('/dashboard/stats');

// Orders
export const createOrderAPI = (data) => API.post('/orders', data);
export const getMyOrdersAPI = () => API.get('/orders/my');
export const cancelOrderRequestAPI = (id, reason) => API.put(`/orders/${id}/cancel-request`, { reason });
export const getAdminOrdersAPI = (params) => API.get('/orders/admin/all', { params });
export const updateOrderStatusAPI = (id, data) => API.put(`/orders/admin/${id}/status`, data);
export const getOrderStatsAPI = () => API.get('/orders/admin/stats');

// Payment (Razorpay)
export const getRazorpayKeyAPI = () => API.get('/payment/razorpay-order'); // key embedded in order
export const createRazorpayOrderAPI = (data) => API.post('/payment/razorpay-order', data);
export const verifyRazorpayPaymentAPI = (data) => API.post('/payment/verify', data);

// AI Chat
export const aiChatAPI = (data) => API.post('/chat', data);
export const aiAnalyticsAPI = () => API.get('/chat/stats');

// Contact
export const contactAPI = (data) => API.post('/contact', data);

export default API;